package Controlador;

import Modelo.ModeloPersona;
import Modelo.Persona;
import Vista.MenuPrincipal;
import java.util.List;
import java.util.Optional;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorPersona {

    private ModeloPersona modelo;
    private MenuPrincipal vista;

    public ControladorPersona(ModeloPersona modelo, MenuPrincipal vista) {
        this.modelo = modelo;
        this.vista = vista;
        vista.setVisible(true);
        cargarPersonas();
    }

    public void iniciarControl() {
        vista.getBtnNuevo().addActionListener(l -> abrirDialogo("Crear"));
        vista.getBtnEditar().addActionListener(l -> abrirDialogo("Editar"));
        vista.getBtnEliminar().addActionListener(l -> abrirDialogo("Eliminar"));
        vista.getBtnAceptar().addActionListener(l -> crearEditarPersona());
    }

    private void crearEditarPersona() {
        if (vista.getDialogPersona().getTitle().contentEquals("Crear")) {
            ModeloPersona modeloPersona = new ModeloPersona();

            if (vista.getTxtIdpersona().getText().equals("") || vista.getTxtNombre().getText().equals("") || vista.getTxtApellido().getText().equals("")) {
                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");
            } else {
                String cedula = vista.getTxtIdpersona().getText();
                String nombre = vista.getTxtNombre().getText();
                String apellido = vista.getTxtApellido().getText();

                if (cedulaExiste(cedula)) {
                    JOptionPane.showMessageDialog(null, "La cédula ya existe. Por favor, ingrese una cédula diferente.");
                } else if (!validarCedula(cedula)) {
                    JOptionPane.showMessageDialog(null, "La cédula debe tener 10 dígitos.");
                } else if (!validarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "El nombre debe ser válido");
                } else if (!validarApellido(apellido)) {
                    JOptionPane.showMessageDialog(null, "El apellido debe ser válido");
                } else {
                    modeloPersona.setIdPersona(cedula);
                    modeloPersona.setNombre(nombre);
                    modeloPersona.setApellido(apellido);

                    if (modeloPersona.grabarPersona()) {
                        JOptionPane.showMessageDialog(vista, "DATOS CREADOS");
                        vista.getDialogPersona().setVisible(false);
                        cargarPersonas();
                        limpiar();
                    } else {
                        JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
                    }
                }
            }
        } else if (vista.getDialogPersona().getTitle().contentEquals("Editar")) {
            ModeloPersona modeloPersona = new ModeloPersona();

            if (vista.getTxtIdpersona().getText().equals("") || vista.getTxtNombre().getText().equals("") || vista.getTxtApellido().getText().equals("")) {
                JOptionPane.showMessageDialog(null, "POR FAVOR LLENE LOS DATOS");
            } else {
                String cedula = vista.getTxtIdpersona().getText();
                String nombre = vista.getTxtNombre().getText();
                String apellido = vista.getTxtApellido().getText();

                if (!validarCedula(cedula)) {
                    JOptionPane.showMessageDialog(null, "El campo de cédula debe tener 10 dígitos.");
                } else if (!validarNombre(nombre)) {
                    JOptionPane.showMessageDialog(null, "El nombre debe ser válido");
                } else if (!validarApellido(apellido)) {
                    JOptionPane.showMessageDialog(null, "El apellido debe ser válido");
                } else {
                    modeloPersona.setIdPersona(cedula);
                    modeloPersona.setNombre(nombre);
                    modeloPersona.setApellido(apellido);

                    if (modeloPersona.modificarPersona()) {
                        JOptionPane.showMessageDialog(vista, "DATOS MODIFICADOS");
                        vista.getDialogPersona().setVisible(false);
                        cargarPersonas();
                        limpiar();
                    } else {
                        JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
                    }
                }
            }
        } else if (vista.getDialogPersona().getTitle().contentEquals("Eliminar")) {
            ModeloPersona modeloPersona = new ModeloPersona();
            modeloPersona.setIdPersona(vista.getTxtIdpersona().getText());

            if (modeloPersona.eliminarPersona()) {
                JOptionPane.showMessageDialog(vista, "DATOS ELIMINADOS");
                vista.getDialogPersona().setVisible(false);
                cargarPersonas();
            } else {
                JOptionPane.showMessageDialog(vista, "ERROR AL GRABAR DATOS");
            }
        }
    }

    public void limpiar() {
        vista.getTxtIdpersona().setText("");
        vista.getTxtNombre().setText("");
        vista.getTxtApellido().setText("");
        vista.getTxtIdpersona().setEnabled(true);
    }

    private void abrirDialogo(String tipo) {
        vista.getDialogPersona().setLocationRelativeTo(null);
        vista.getDialogPersona().setSize(750, 600);
        vista.getDialogPersona().setTitle(tipo);
        vista.getDialogPersona().setVisible(true);

        if (vista.getDialogPersona().getTitle().contentEquals("Crear")) {
            // No se necesita hacer nada adicional
        } else if (vista.getDialogPersona().getTitle().contentEquals("Editar")) {
            llenarDatos();
        } else if (vista.getDialogPersona().getTitle().contentEquals("Eliminar")) {
            llenarDatos();
        }
    }

    public void cargarPersonas() {
        DefaultTableModel modeloTabla = (DefaultTableModel) vista.getTblPersonas().getModel();
        modeloTabla.setNumRows(0);

        List<Persona> listaPersonas = modelo.listarPersonas();

        listaPersonas.forEach(persona -> {
            String[] rowData = {persona.getIdPersona(), persona.getNombre(), persona.getApellido()};
            modeloTabla.addRow(rowData);
        });
    }

    public void llenarDatos() {
        List<Persona> listaPersonas = modelo.listarPersonas();
        int selectedRow = vista.getTblPersonas().getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Para que los datos se llenen, debe seleccionar un elemento de la tabla");
        } else {
            String selectedId = vista.getTblPersonas().getValueAt(selectedRow, 0).toString();
            Optional<Persona> matchingPersona = listaPersonas.stream()
                    .filter(persona -> selectedId.equals(persona.getIdPersona()))
                    .findFirst();

            if (matchingPersona.isPresent()) {
                Persona persona = matchingPersona.get();
                vista.getTxtIdpersona().setText(persona.getIdPersona());
                vista.getTxtIdpersona().setEnabled(false);
                vista.getTxtNombre().setText(persona.getNombre());
                vista.getTxtApellido().setText(persona.getApellido());
            } else {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento válido de la tabla.");
            }
        }
    }

    private boolean cedulaExiste(String cedula) {
        List<Persona> listaPersonas = modelo.listarPersonas();

        for (Persona persona : listaPersonas) {
            if (persona.getIdPersona().equals(cedula)) {
                return true;
            }
        }

        return false;
    }

    public boolean validarNombre(String nombre) {
        return nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,50}");
    }

    public boolean validarApellido(String apellido) {
        return apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{2,50}");
    }

    public boolean validarCedula(String cedula) {
        return cedula.matches("\\d{10}");
    }
}
